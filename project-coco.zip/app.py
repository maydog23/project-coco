# Streamlit dashboard entry point

import streamlit as st
st.title("Project Coco: Cruise Suite Tracker")